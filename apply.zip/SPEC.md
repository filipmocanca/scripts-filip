SPEC.md - IT Trainings in Luxembourg
1. Tech Stack
Frontend: React 18 (Vite), TypeScript 5.x

Styling: Tailwind CSS, Shadcn/UI (Radix UI primitives)

State & Data: TanStack Query v5 (Framer Motion for sliding menus)

Backend/Auth: Supabase (PostgreSQL, Storage for doc uploads, Auth for Admin)

Deployment: Vercel or Netlify

2. Naming Conventions
Files: PascalCase for components (CourseCard.tsx), kebab-case for utilities (date-formatter.ts).

Components: Functional components with arrow functions.

Variables/Functions: camelCase.

Types/Interfaces: PascalCase prefixed with I or T (optional), e.g., ICourse.

Database: snake_case for tables and columns.

3. Folder Structure
Plaintext
src/
├── api/              # Supabase clients and TanStack Query hooks
├── components/       # Shared UI (atoms/molecules)
│   ├── ui/           # Shadcn/UI components
│   └── shared/       # Navigation, Layout, SlidingMenu
├── features/         # Logic-specific modules
│   ├── catalog/      # Offers, Course details
│   ├── admin/        # Dashboard, Upload logic
│   └── registration/ # Forms
├── hooks/            # Global custom hooks
├── lib/              # Utils (parsing logic, constants)
├── types/            # TypeScript interfaces
└── views/            # Page-level components (Home, Offer, etc.)
4. Key Constraints & Non-Negotiables
Sliding Menus: Navigation must be handled via Framer Motion or CSS transitions to ensure the "sliding" requirement from the PRD.

Parsing Logic: The system must handle .txt parsing on the client-side or via Supabase Edge Functions before inserting into the DB.

Strict Typing: any is forbidden; all Supabase responses must be typed.

Responsive Design: Mobile-first approach using Tailwind.

Admin Access: Only one authenticated Admin role can access /admin.

5. Data Model (Supabase/Postgres)
Table: courses
id: uuid (PK)

title: text

price: numeric

duration_days: integer

description: text (extracted from file)

created_at: timestamp

Table: leads
id: uuid (PK)

course_id: uuid (FK -> courses.id)

full_name: text

address: text

phone: text

email: text

status: text (default: 'pending')

created_at: timestamp

Table: jobs
id: uuid (PK)

title: text

company: text

description: text

link: text

6. Implementation Logic: File Parsing
Admin Uploads: Admin selects a .txt file via a Shadcn Input component.

Extraction: A utility function uses Regex to find patterns:

Price: (\d+)\s?euro

Duration: (\d+)\s?day

Title: First line of document.

Validation: Admin previews the parsed data in a modal before final "Submit" to the courses table.