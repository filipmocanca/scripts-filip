ROADMAP.md - IT Trainings in Luxembourg

🎯 Project Strategy

V0 Goal: A functional "Offer" page that pulls real data from Supabase and a working Registration form (local state only).



Constraint: Zero Auth, Zero Write Ops, Zero File Parsing in V0 to save AI generation tokens.



🏗️ Sprint 0: V0 Generation (The "Infrastructure" Build)

Goal: Prove the stack works and establish the Supabase tunnel.



✅ Must Generate (Build Now)

\[ ] Project Shell: Vite + React + Tailwind + Shadcn/UI base.



\[ ] Sliding Navigation: Basic 5-tab structure with Framer Motion transitions.



\[ ] Supabase Foundation: \* Initialize supabaseClient.ts.



Create courses table in Supabase.



The "Must-Read": Fetch the 3 initial courses (Java, Python, SysAdmin) from Supabase via TanStack Query.



\[ ] The "Offer" View: Display the fetched course cards (Title, Price, Duration).



\[ ] Registration UI: A Shadcn-based modal/form (Name, Address, Phone, Email) that console-logs the data on submit (no DB write yet).



\[ ] Visual Identity: Blue/White theme with the "Person at PC" logo placeholder.



⏳ Defer to Sprint 1+ (Do Not Generate)

\[ ] Admin Dashboard: No /admin route or Lead management.



\[ ] Auth: No login/logout logic.



\[ ] File Parsing: No .txt upload or processing.



\[ ] DB Writes: No leads table insertion.



\[ ] Content: "Jobs" and "Discounts" tabs will remain as "Coming Soon" placeholders.



🚀 Sprint 1: Admin \& Write Operations

(To be detailed after V0 validation)



\[ ]



\[ ]



📈 Sprint 2: Automation \& Refinement

(To be detailed after Sprint 1)



\[ ]



\[ ]

