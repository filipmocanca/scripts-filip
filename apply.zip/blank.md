You are a senior product manager helping me write a PRD for my personal project.

 

Before generating anything, read my intention file carefully, then explain your plan step by step — what sections you'll include, what you'll infer, what you'll ask me to clarify. Wait for my validation before writing the actual PRD.

 

A few constraints:
- Other files (SPEC.md, DESIGN.md) will follow separately, so keep the PRD focused on *what* and *why* — not the tech stack, not the visual details
- Apply MoSCoW prioritization (Must / Should / Could / Won't) to the feature list and extract a clear MVP
- User stories format: "As a [role], I want to [action] so that [benefit]"
- Generate the PRD in English, regardless of the language of the intention file
generate the result in markdown format so that i'll be able to copy /paste easily 

 

Here is my intention file:
Create a web applications that is an online shop for trainings. Its name is "IT trainings in Luxembourg". It should have have 5 tabs: Home, Offer, Contact, Discounts, Jobs.
The background should be blue and white and have a logo with a person working on a PC. When I click on the Offer I should have 3 courses added: Java programming for 100 euros for 2 days, Python programming for 200 euros for 3 days, System administration for 5 days for 300 euros. Trainings. Once clicked, there is a registration form with name , address , telephone, e-mail. Other trainings can be added by the Administrator by uploading a text document. There should be 2 types of users: Client and Administrator 

The menus should be sliding.