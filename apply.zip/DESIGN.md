PRD: IT Trainings in Luxembourg
1. Executive Summary
IT Trainings in Luxembourg is a specialized web platform designed to bridge the gap between IT professionals/aspirants and high-quality technical training within the Luxembourg region. The platform serves as a digital storefront for a curated catalog of courses, a lead generation tool for registrations, and a portal for regional IT job opportunities.
2. Target Audience & User Personas
PersonaDescriptionGoalsThe ClientProfessionals or students in Luxembourg seeking to upscale their IT skills.To browse available courses, view pricing/duration, and register for training easily.The AdministratorThe site owner/manager responsible for operations.To manage the course catalog via document uploads and track registration leads via a dashboard.
3. User Stories
3.1 Client Stories
As a Client, I want to navigate through a sliding menu so that I can easily switch between the home page, offers, and job listings.
As a Client, I want to view the specific details of a course (price, duration) so that I can make an informed decision.
As a Client, I want to fill out a registration form so that I can sign up for a training session.
As a Client, I want to see a dedicated "Discounts" section so that I can find more affordable training options.
As a Client, I want to browse a "Jobs" section so that I can see relevant employment opportunities in the Luxembourg IT sector.
3.2 Administrator Stories
As an Admin, I want to upload a text document so that the system automatically parses it and adds new courses to the "Offer" page.
As an Admin, I want a centralized dashboard so that I can view and manage the contact details of clients who have registered.
As an Admin, I want to receive an email confirmation of payment from the client so that I can finalize their enrollment offline.
4. Functional Requirements
4.1 Navigation & Structure
The application shall feature 5 primary sections: Home, Offer, Contact, Discounts, Jobs.
Navigation menus must utilize a sliding animation transition.
4.2 Course Catalog (Offer)
The system shall display an initial catalog of three "Starter" courses:
Java programming: 100 EUR, 2 days.
Python programming: 200 EUR, 3 days.
System administration: 300 EUR, 5 days.
Each course entry must have a "Register" trigger.
4.3 Registration & Lead Management
Registration Form: Must collect Name, Address, Telephone, and Email.
Lead Dashboard: A secure area where the Admin can view a list of all submitted registrations.
Payment Workflow: No automated payment gateway. The system must instruct the user to send payment confirmation via email after registration.
4.4 Automated Content Management
The Admin shall have the ability to upload .txt or .docx files.
The system must parse these documents to extract: Course Name, Price, and Duration to automatically update the "Offer" tab.
5. Feature Prioritization (MoSCoW)
Must Have (MVP)
Sliding menu navigation with the 5 defined tabs.
The "Offer" page with the 3 initial courses.
Functional Registration Form and Admin Dashboard for lead tracking.
Offline payment instruction workflow.
Should Have
The automated Document Upload/Parsing system for new courses.
"Contact" form functionality for general inquiries.
Could Have
Search/Filter functionality for the "Jobs" and "Offer" sections.
Email notifications to the Admin when a new lead is registered.
Won't Have (This Version)
Integrated Payment Gateway (Stripe/PayPal).
User accounts for Clients (registration is guest-based).
Real-time chat support.
6. Non-Functional Requirements
Language: The user interface and all content shall be in English.
Accessibility: The registration form must be easily navigable on both desktop and mobile devices.
Data Privacy: Client data collected in the dashboard must be handled securely and only accessible by the Administrator.