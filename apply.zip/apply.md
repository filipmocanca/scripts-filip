## Visual North Star

 

The screenshots attached are mockups generated in Stitch.

Use them as your visual north star — match the overall layout,

component shapes, spacing proportions, typography weight hierarchy,

and color palette as closely as possible.

 

You do NOT need to be pixel-perfect — adapt for React/Tailwind constraints —

but the visual intent MUST be preserved. If a DESIGN.md directive conflicts

with a screenshot, the DESIGN.md takes precedence.

 

Your task: build the V0 frontend — the Sprint 0 scope defined in ROADMAP.md only.
Use the exact stack specified in SPEC.md.

 

⚠️ CRITICAL CONSTRAINTS:
1. Only implement what is listed under "Must Generate" in ROADMAP.md Sprint 0.
2. Do NOT start anything listed under "Defer to Sprint 1+" — a partial auth or a 
   half-done feature is worse than no feature at all.
3. When Sprint 0 is complete: STOP. Give me a summary of what was built and wait 
   for my instruction before touching anything else.
4. Use ONLY the Supabase project already connected in your Settings panel.
   DO NOT create a new Supabase project. DO NOT offer to enable Lovable Cloud.
   If you cannot detect a connected Supabase project, STOP and tell me immediately
   — do not proceed until I confirm the connection is set up.
5. FALLBACK — if and only if you cannot apply the Supabase migrations automatically,
   output the complete SQL creation script for all tables defined in SPEC.md
   (family_members, profiles, media, historical_events), including all columns,
   types, constraints, foreign keys, and RLS policies. Format it as a single
   copy-pasteable SQL block I can run in the Supabase SQL Editor. Do NOT skip this
   step if migrations fail — the script is mandatory, not optional.

 

Before building, explain your approach step by step. List exactly what you will 
build and confirm it matches the Sprint 0 scope. Wait for my validation before 
writing a single line of code.

 6. The backend should be implemented in Supabase. Here is the project URL: https://wyezatnvknbkdywolaaa.supabase.co and the publishable key: sb_publishable_b5QML1jGzL7RhtfZCTGNew_-Mtj4JKJ

--- PRD.md ---
PRD: IT Trainings in Luxembourg1. Executive SummaryIT Trainings in Luxembourg is a specialized web platform designed to bridge the gap between IT professionals/aspirants and high-quality technical training within the Luxembourg region. The platform serves as a digital storefront for a curated catalog of courses, a lead generation tool for registrations, and a portal for regional IT job opportunities.2. Target Audience & User PersonasPersonaDescriptionGoalsThe ClientProfessionals or students in Luxembourg seeking to upscale their IT skills.To browse available courses, view pricing/duration, and register for training easily.The AdministratorThe site owner/manager responsible for operations.To manage the course catalog via document uploads and track registration leads via a dashboard.3. User Stories3.1 Client StoriesAs a Client, I want to navigate through a sliding menu so that I can easily switch between the home page, offers, and job listings.As a Client, I want to view the specific details of a course (price, duration) so that I can make an informed decision.As a Client, I want to fill out a registration form so that I can sign up for a training session.As a Client, I want to see a dedicated "Discounts" section so that I can find more affordable training options.As a Client, I want to browse a "Jobs" section so that I can see relevant employment opportunities in the Luxembourg IT sector.3.2 Administrator StoriesAs an Admin, I want to upload a text document so that the system automatically parses it and adds new courses to the "Offer" page.As an Admin, I want a centralized dashboard so that I can view and manage the contact details of clients who have registered.As an Admin, I want to receive an email confirmation of payment from the client so that I can finalize their enrollment offline.4. Functional Requirements4.1 Navigation & StructureThe application shall feature 5 primary sections: Home, Offer, Contact, Discounts, Jobs.Navigation menus must utilize a sliding animation transition.4.2 Course Catalog (Offer)The system shall display an initial catalog of three "Starter" courses:Java programming: 100 EUR, 2 days.Python programming: 200 EUR, 3 days.System administration: 300 EUR, 5 days.Each course entry must have a "Register" trigger.4.3 Registration & Lead ManagementRegistration Form: Must collect Name, Address, Telephone, and Email.Lead Dashboard: A secure area where the Admin can view a list of all submitted registrations.Payment Workflow: No automated payment gateway. The system must instruct the user to send payment confirmation via email after registration.4.4 Automated Content ManagementThe Admin shall have the ability to upload .txt or .docx files.The system must parse these documents to extract: Course Name, Price, and Duration to automatically update the "Offer" tab.5. Feature Prioritization (MoSCoW)Must Have (MVP)Sliding menu navigation with the 5 defined tabs.The "Offer" page with the 3 initial courses.Functional Registration Form and Admin Dashboard for lead tracking.Offline payment instruction workflow.Should HaveThe automated Document Upload/Parsing system for new courses."Contact" form functionality for general inquiries.Could HaveSearch/Filter functionality for the "Jobs" and "Offer" sections.Email notifications to the Admin when a new lead is registered.Won't Have (This Version)Integrated Payment Gateway (Stripe/PayPal).User accounts for Clients (registration is guest-based).Real-time chat support.6. Non-Functional RequirementsLanguage: The user interface and all content shall be in English.Accessibility: The registration form must be easily navigable on both desktop and mobile devices.Data Privacy: Client data collected in the dashboard must be handled securely and only accessible by the Administrator.

 

--- SPEC.md ---
SPEC.md - IT Trainings in Luxembourg
1. Tech Stack
Frontend: React 18 (Vite), TypeScript 5.x

Styling: Tailwind CSS, Shadcn/UI (Radix UI primitives)

State & Data: TanStack Query v5 (Framer Motion for sliding menus)

Backend/Auth: Supabase (PostgreSQL, Storage for doc uploads, Auth for Admin)

Deployment: Vercel or Netlify

2. Naming Conventions
Files: PascalCase for components (CourseCard.tsx), kebab-case for utilities (date-formatter.ts).

Components: Functional components with arrow functions.

Variables/Functions: camelCase.

Types/Interfaces: PascalCase prefixed with I or T (optional), e.g., ICourse.

Database: snake_case for tables and columns.

3. Folder Structure
Plaintext
src/
├── api/              # Supabase clients and TanStack Query hooks
├── components/       # Shared UI (atoms/molecules)
│   ├── ui/           # Shadcn/UI components
│   └── shared/       # Navigation, Layout, SlidingMenu
├── features/         # Logic-specific modules
│   ├── catalog/      # Offers, Course details
│   ├── admin/        # Dashboard, Upload logic
│   └── registration/ # Forms
├── hooks/            # Global custom hooks
├── lib/              # Utils (parsing logic, constants)
├── types/            # TypeScript interfaces
└── views/            # Page-level components (Home, Offer, etc.)
4. Key Constraints & Non-Negotiables
Sliding Menus: Navigation must be handled via Framer Motion or CSS transitions to ensure the "sliding" requirement from the PRD.

Parsing Logic: The system must handle .txt parsing on the client-side or via Supabase Edge Functions before inserting into the DB.

Strict Typing: any is forbidden; all Supabase responses must be typed.

Responsive Design: Mobile-first approach using Tailwind.

Admin Access: Only one authenticated Admin role can access /admin.

5. Data Model (Supabase/Postgres)
Table: courses
id: uuid (PK)

title: text

price: numeric

duration_days: integer

description: text (extracted from file)

created_at: timestamp

Table: leads
id: uuid (PK)

course_id: uuid (FK -> courses.id)

full_name: text

address: text

phone: text

email: text

status: text (default: 'pending')

created_at: timestamp

Table: jobs
id: uuid (PK)

title: text

company: text

description: text

link: text

6. Implementation Logic: File Parsing
Admin Uploads: Admin selects a .txt file via a Shadcn Input component.

Extraction: A utility function uses Regex to find patterns:

Price: (\d+)\s?euro

Duration: (\d+)\s?day

Title: First line of document.

Validation: Admin previews the parsed data in a modal before final "Submit" to the courses table.

 

--- DESIGN.md ---
PRD: IT Trainings in Luxembourg
1. Executive Summary
IT Trainings in Luxembourg is a specialized web platform designed to bridge the gap between IT professionals/aspirants and high-quality technical training within the Luxembourg region. The platform serves as a digital storefront for a curated catalog of courses, a lead generation tool for registrations, and a portal for regional IT job opportunities.
2. Target Audience & User Personas
PersonaDescriptionGoalsThe ClientProfessionals or students in Luxembourg seeking to upscale their IT skills.To browse available courses, view pricing/duration, and register for training easily.The AdministratorThe site owner/manager responsible for operations.To manage the course catalog via document uploads and track registration leads via a dashboard.
3. User Stories
3.1 Client Stories
As a Client, I want to navigate through a sliding menu so that I can easily switch between the home page, offers, and job listings.
As a Client, I want to view the specific details of a course (price, duration) so that I can make an informed decision.
As a Client, I want to fill out a registration form so that I can sign up for a training session.
As a Client, I want to see a dedicated "Discounts" section so that I can find more affordable training options.
As a Client, I want to browse a "Jobs" section so that I can see relevant employment opportunities in the Luxembourg IT sector.
3.2 Administrator Stories
As an Admin, I want to upload a text document so that the system automatically parses it and adds new courses to the "Offer" page.
As an Admin, I want a centralized dashboard so that I can view and manage the contact details of clients who have registered.
As an Admin, I want to receive an email confirmation of payment from the client so that I can finalize their enrollment offline.
4. Functional Requirements
4.1 Navigation & Structure
The application shall feature 5 primary sections: Home, Offer, Contact, Discounts, Jobs.
Navigation menus must utilize a sliding animation transition.
4.2 Course Catalog (Offer)
The system shall display an initial catalog of three "Starter" courses:
Java programming: 100 EUR, 2 days.
Python programming: 200 EUR, 3 days.
System administration: 300 EUR, 5 days.
Each course entry must have a "Register" trigger.
4.3 Registration & Lead Management
Registration Form: Must collect Name, Address, Telephone, and Email.
Lead Dashboard: A secure area where the Admin can view a list of all submitted registrations.
Payment Workflow: No automated payment gateway. The system must instruct the user to send payment confirmation via email after registration.
4.4 Automated Content Management
The Admin shall have the ability to upload .txt or .docx files.
The system must parse these documents to extract: Course Name, Price, and Duration to automatically update the "Offer" tab.
5. Feature Prioritization (MoSCoW)
Must Have (MVP)
Sliding menu navigation with the 5 defined tabs.
The "Offer" page with the 3 initial courses.
Functional Registration Form and Admin Dashboard for lead tracking.
Offline payment instruction workflow.
Should Have
The automated Document Upload/Parsing system for new courses.
"Contact" form functionality for general inquiries.
Could Have
Search/Filter functionality for the "Jobs" and "Offer" sections.
Email notifications to the Admin when a new lead is registered.
Won't Have (This Version)
Integrated Payment Gateway (Stripe/PayPal).
User accounts for Clients (registration is guest-based).
Real-time chat support.
6. Non-Functional Requirements
Language: The user interface and all content shall be in English.
Accessibility: The registration form must be easily navigable on both desktop and mobile devices.
Data Privacy: Client data collected in the dashboard must be handled securely and only accessible by the Administrator.

 

--- ROADMAP.md ---
ROADMAP.md - IT Trainings in Luxembourg

🎯 Project Strategy

V0 Goal: A functional "Offer" page that pulls real data from Supabase and a working Registration form (local state only).



Constraint: Zero Auth, Zero Write Ops, Zero File Parsing in V0 to save AI generation tokens.



🏗️ Sprint 0: V0 Generation (The "Infrastructure" Build)

Goal: Prove the stack works and establish the Supabase tunnel.



✅ Must Generate (Build Now)

\[ ] Project Shell: Vite + React + Tailwind + Shadcn/UI base.



\[ ] Sliding Navigation: Basic 5-tab structure with Framer Motion transitions.



\[ ] Supabase Foundation: \* Initialize supabaseClient.ts.



Create courses table in Supabase.



The "Must-Read": Fetch the 3 initial courses (Java, Python, SysAdmin) from Supabase via TanStack Query.



\[ ] The "Offer" View: Display the fetched course cards (Title, Price, Duration).



\[ ] Registration UI: A Shadcn-based modal/form (Name, Address, Phone, Email) that console-logs the data on submit (no DB write yet).



\[ ] Visual Identity: Blue/White theme with the "Person at PC" logo placeholder.



⏳ Defer to Sprint 1+ (Do Not Generate)

\[ ] Admin Dashboard: No /admin route or Lead management.



\[ ] Auth: No login/logout logic.



\[ ] File Parsing: No .txt upload or processing.



\[ ] DB Writes: No leads table insertion.



\[ ] Content: "Jobs" and "Discounts" tabs will remain as "Coming Soon" placeholders.

Create a Supabase table called courses with columns title, price, and duration. Seed it with 3 rows. Use TanStack Query to fetch and display these rows on the 'Offer' tab.



🚀 Sprint 1: Admin \& Write Operations

(To be detailed after V0 validation)



\[ ]



\[ ]



📈 Sprint 2: Automation \& Refinement

(To be detailed after Sprint 1)



\[ ]



\[ ]



 

Chain of Thought instruction: think step by step. Explain before you build.
Sprint 0 done → stop and report. Do not proceed to Sprint 1 autonomously.